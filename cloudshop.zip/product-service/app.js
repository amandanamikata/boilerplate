const express = require('express');
const app = express();
const PORT = 8080;

app.get('/products', (req, res) => {
  res.json([
    { id: 1, name: 'Azure T-shirt', price: 25 },
    { id: 2, name: 'Cloud Mug', price: 12 },
    { id: 3, name: 'K8s Sticker Pack', price: 5 },
  ]);
});

app.listen(PORT, () => console.log(`Product service running on port ${PORT}`));
