from fastapi import FastAPI, Request

app = FastAPI()

@app.post("/order")
async def create_order(request: Request):
    body = await request.json()
    return {"status": "Order received", "order": body}
